// CloudBite backend: one Vercel serverless function + MongoDB Atlas. Env: MONGODB_URI, JWT_SECRET
const { MongoClient } = require('mongodb');
const crypto = require('crypto');
const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const AREAS = ['Adyar', 'T Nagar', 'Anna Nagar', 'Velachery', 'Tambaram', 'Guindy'];
const DISC = 30; // % discount on rescued food = % charged to the canceller
const id = () => crypto.randomUUID();
const E = (s, m) => Object.assign(new Error(m), { status: s });
const C = (d, n) => d.collection(n);
const sum = a => a.reduce((s, x) => s + x, 0);
const pub = u => ({ id: u._id, role: u.role, name: u.name, email: u.email, area: u.area });

let cache;
const getDb = () => cache || (cache = new MongoClient(process.env.MONGODB_URI).connect().then(async c => {
  const d = c.db('cloudbite'); await d.collection('users').createIndex({ email: 1 }, { unique: true }); return d;
}).catch(e => { cache = null; throw e; }));

const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
const mac = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
const sign = p => { const h = b64({ alg: 'HS256', typ: 'JWT' }) + '.' + b64({ ...p, exp: Date.now() / 1000 + 7 * 86400 }); return h + '.' + mac(h); };
const verify = t => { try { const [a, b, s] = t.split('.'); if (mac(a + '.' + b) !== s) return null; const p = JSON.parse(Buffer.from(b, 'base64url')); return p.exp > Date.now() / 1000 ? p : null; } catch { return null; } };
const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const check = (pw, h) => hash(pw, h.split(':')[0]) === h;

const R = [];
const on = (m, p, role, f) => R.push([m, new RegExp('^' + p.replace(/:\w+/g, '([^/]+)') + '$'), role, f]);
const mk = o => ({ _id: id(), agentId: null, agentName: null, refund: 0, note: '', rescued: false, lateCancelled: false, chargeAmount: 0, chargeStatus: null, extra: 0, createdAt: new Date(), ...o });

// ---------- auth ----------
on('POST', '/auth/register', null, async ({ d, b }) => {
  const { role, name, email, password, area } = b;
  if (!['customer', 'restaurant', 'agent'].includes(role) || !name || !email || !password || password.length < 6 || !AREAS.includes(area)) throw E(400, 'Fill all fields (password: minimum 6 characters).');
  const u = { _id: id(), role, name: name.trim(), email: email.toLowerCase().trim(), pass: hash(password), area, createdAt: new Date() };
  try { await C(d, 'users').insertOne(u); } catch (e) { throw E(e.code === 11000 ? 409 : 500, e.code === 11000 ? 'This email is already registered.' : e.message); }
  if (role === 'restaurant') {
    const r = { _id: id(), ownerId: u._id, name: (b.restaurantName || name).trim(), cuisine: b.cuisine || 'Multi-cuisine', area };
    await C(d, 'restaurants').insertOne(r);
    await C(d, 'menu').insertMany([['Chicken Biryani', 300, 'Basmati rice, spiced chicken, raita', false, '🍛'], ['Paneer Wrap', 180, 'Paneer tikka in a soft roll', true, '🌯'], ['Masala Dosa', 120, 'Crispy dosa with potato masala', true, '🥞']]
      .map(([name, price, desc, veg, emoji]) => ({ _id: id(), restaurantId: r._id, name, price, desc, veg, emoji, available: true })));
  }
  return { token: sign({ id: u._id }), user: pub(u) };
});
on('POST', '/auth/login', null, async ({ d, b }) => {
  const u = await C(d, 'users').findOne({ email: String(b.email || '').toLowerCase().trim() });
  if (!u || !check(String(b.password || ''), u.pass)) throw E(401, 'Wrong email or password.');
  if (b.role && b.role !== u.role) throw E(403, `This is a ${u.role} account. Please use the ${u.role} tab.`);
  return { token: sign({ id: u._id }), user: pub(u) };
});
on('POST', '/me/area', 'customer', async ({ d, u, b }) => {
  if (!AREAS.includes(b.area)) throw E(400, 'Unknown area.');
  await C(d, 'users').updateOne({ _id: u._id }, { $set: { area: b.area } }); return { ok: true };
});

// ---------- customer: browse + cart ----------
on('GET', '/restaurants', 'customer', async ({ d, u, q }) => ({ restaurants: await C(d, 'restaurants').find(q.area === 'all' ? {} : { area: q.area || u.area }).toArray() }));
on('GET', '/restaurants/:id', 'customer', async ({ d, p }) => {
  const restaurant = await C(d, 'restaurants').findOne({ _id: p[0] }); if (!restaurant) throw E(404, 'Restaurant not found.');
  return { restaurant, menu: await C(d, 'menu').find({ restaurantId: p[0], available: true }).toArray() };
});
async function cartView(d, u) {
  const c = (await C(d, 'carts').findOne({ _id: u._id })) || { items: [] };
  const ch = await C(d, 'charges').find({ userId: u._id, status: 'pending' }).toArray();
  const subtotal = sum(c.items.map(i => i.price * i.qty)), extra = sum(ch.map(x => x.amount));
  return { restaurantName: c.restaurantName || '', items: c.items, subtotal, extra, total: subtotal + extra, count: sum(c.items.map(i => i.qty)) };
}
on('GET', '/cart', 'customer', ({ d, u }) => cartView(d, u));
on('POST', '/cart/add', 'customer', async ({ d, u, b }) => {
  const it = await C(d, 'menu').findOne({ _id: b.itemId }); if (!it || !it.available) throw E(404, 'Item not available.');
  const r = await C(d, 'restaurants').findOne({ _id: it.restaurantId });
  let c = await C(d, 'carts').findOne({ _id: u._id });
  if (c && c.items.length && c.restaurantId !== it.restaurantId) { if (!b.replace) throw E(409, `Your cart has items from ${c.restaurantName}. Start a new cart?`); c = null; }
  c = c || { _id: u._id, restaurantId: r._id, restaurantName: r.name, items: [] };
  const l = c.items.find(i => i.itemId === it._id); l ? l.qty++ : c.items.push({ itemId: it._id, name: it.name, price: it.price, qty: 1 });
  await C(d, 'carts').replaceOne({ _id: u._id }, c, { upsert: true }); return cartView(d, u);
});
on('POST', '/cart/update', 'customer', async ({ d, u, b }) => {
  const c = await C(d, 'carts').findOne({ _id: u._id });
  if (c) { c.items = c.items.map(i => i.itemId === b.itemId ? { ...i, qty: Math.max(0, +b.qty | 0) } : i).filter(i => i.qty > 0); await C(d, 'carts').replaceOne({ _id: u._id }, c); }
  return cartView(d, u);
});

// ---------- customer: orders, cancel, rescue ----------
on('POST', '/orders', 'customer', async ({ d, u, b }) => {
  const c = await C(d, 'carts').findOne({ _id: u._id }); if (!c || !c.items.length) throw E(400, 'Your cart is empty.');
  const v = await cartView(d, u), r = await C(d, 'restaurants').findOne({ _id: c.restaurantId });
  const pend = await C(d, 'charges').find({ userId: u._id, status: 'pending' }).toArray();
  const o = mk({ customerId: u._id, customerName: u.name, restaurantId: r._id, restaurantName: r.name, area: r.area, items: c.items, subtotal: v.subtotal, extra: v.extra, total: v.total,
    paid: !!b.paid, status: 'Placed', note: v.extra ? `Includes ₹${v.extra} cancellation charge from an earlier order.` : '' });
  await C(d, 'orders').insertOne(o);
  for (const x of pend) { await C(d, 'charges').updateOne({ _id: x._id }, { $set: { status: 'applied', orderId: o._id } }); await C(d, 'orders').updateOne({ _id: x.fromOrder }, { $set: { chargeStatus: 'applied' } }); }
  await C(d, 'carts').deleteOne({ _id: u._id }); return { order: o };
});
on('GET', '/orders', 'customer', async ({ d, u }) => ({ orders: await C(d, 'orders').find({ customerId: u._id }).sort({ createdAt: -1 }).toArray() }));
on('GET', '/notifications', 'customer', async ({ d, u }) => ({ notifications: await C(d, 'notifications').find({ userId: u._id }).sort({ createdAt: -1 }).limit(30).toArray() }));
on('POST', '/orders/:id/demo-start', 'customer', async ({ d, u, p }) => { // demo shortcut: pretend the restaurant started cooking
  const r = await C(d, 'orders').updateOne({ _id: p[0], customerId: u._id, status: { $in: ['Placed', 'Accepted'] } }, { $set: { status: 'Preparing' } });
  if (!r.matchedCount) throw E(400, 'Cannot start this order.'); return { ok: true };
});
on('POST', '/orders/:id/cancel', 'customer', async ({ d, u, p }) => {
  const o = await C(d, 'orders').findOne({ _id: p[0], customerId: u._id }); if (!o) throw E(404, 'Order not found.');
  if (!['Placed', 'Accepted', 'Preparing', 'Ready'].includes(o.status)) throw E(400, `This order is already ${o.status}.`);
  if (!['Preparing', 'Ready'].includes(o.status)) { // cooking not started: free cancel
    const note = 'Cancelled before cooking started. No charge.';
    await C(d, 'orders').updateOne({ _id: o._id }, { $set: { status: 'Cancelled', refund: o.paid ? o.total : 0, note } }); return { late: false, message: note };
  }
  const charge = Math.round(o.subtotal * DISC / 100), price = o.subtotal - charge; let note, refund = 0, cs = 'pending';
  if (o.paid) { refund = o.total - charge; cs = 'retained'; note = `Late cancellation. Charge ₹${charge}; refunded ₹${refund}.`; }
  else { await C(d, 'charges').insertOne({ _id: id(), userId: u._id, amount: charge, fromOrder: o._id, status: 'pending' }); note = `Late cancellation. ₹${charge} will be added to your next order.`; }
  await C(d, 'orders').updateOne({ _id: o._id }, { $set: { status: 'Cancelled', refund, note, lateCancelled: true, chargeAmount: charge, chargeStatus: cs } });
  const offer = { _id: id(), orderId: o._id, restaurantId: o.restaurantId, restaurantName: o.restaurantName, area: o.area, items: o.items, title: o.items.map(i => `${i.qty}× ${i.name}`).join(', '),
    originalPrice: o.subtotal, offerPrice: price, discount: charge, cancellerId: u._id, status: 'open', buyerId: null, createdAt: new Date() };
  await C(d, 'offers').insertOne(offer);
  const near = (await C(d, 'users').find({ role: 'customer', area: o.area }).toArray()).filter(x => x._id !== u._id);
  if (near.length) await C(d, 'notifications').insertMany(near.map(x => ({ _id: id(), userId: x._id, offerId: offer._id, createdAt: new Date(),
    message: `${offer.title} from ${o.restaurantName} is available at ₹${price} (was ₹${o.subtotal}) near you.` })));
  return { late: true, message: note, notified: near.length };
});
on('GET', '/offers', 'customer', async ({ d, u }) => ({ offers: (await C(d, 'offers').find({ status: 'open', area: u.area }).toArray()).filter(x => x.cancellerId !== u._id) }));
on('POST', '/offers/:id/claim', 'customer', async ({ d, u, p }) => {
  const f = await C(d, 'offers').findOne({ _id: p[0] }); if (!f) throw E(404, 'Offer not found.');
  if (f.area !== u.area) throw E(403, 'This offer is only for customers in the same area.');
  if (f.cancellerId === u._id) throw E(403, 'You cannot buy the food you cancelled.');
  const r = await C(d, 'offers').updateOne({ _id: f._id, status: 'open' }, { $set: { status: 'sold', buyerId: u._id } }); // atomic: first buyer wins
  if (!r.matchedCount) throw E(409, 'Sorry, this offer was just taken.');
  const o = mk({ customerId: u._id, customerName: u.name, restaurantId: f.restaurantId, restaurantName: f.restaurantName, area: f.area, items: f.items, subtotal: f.offerPrice, total: f.offerPrice,
    paid: true, status: 'Preparing', rescued: true, note: `Rescued food at a discount (saved ₹${f.discount}).` });
  await C(d, 'orders').insertOne(o); return { order: o };
});

// ---------- restaurant ----------
const myR = (d, u) => C(d, 'restaurants').findOne({ ownerId: u._id });
on('GET', '/restaurant/me', 'restaurant', async ({ d, u }) => { const r = await myR(d, u); return { restaurant: r, menu: await C(d, 'menu').find({ restaurantId: r._id }).toArray() }; });
on('POST', '/restaurant/menu', 'restaurant', async ({ d, u, b }) => {
  const r = await myR(d, u); if (!b.name || !(+b.price > 0)) throw E(400, 'Enter a name and a price.');
  await C(d, 'menu').insertOne({ _id: id(), restaurantId: r._id, name: b.name.trim(), price: +b.price, desc: b.desc || '', veg: !!b.veg, emoji: b.veg ? '🥗' : '🍗', available: true }); return { ok: true };
});
on('DELETE', '/restaurant/menu/:id', 'restaurant', async ({ d, u, p }) => { await C(d, 'menu').deleteOne({ _id: p[0], restaurantId: (await myR(d, u))._id }); return { ok: true }; });
on('POST', '/restaurant/menu/:id/toggle', 'restaurant', async ({ d, u, p }) => {
  const m = await C(d, 'menu').findOne({ _id: p[0], restaurantId: (await myR(d, u))._id }); if (m) await C(d, 'menu').updateOne({ _id: m._id }, { $set: { available: !m.available } }); return { ok: true };
});
on('GET', '/restaurant/orders', 'restaurant', async ({ d, u }) => {
  const r = await myR(d, u), orders = await C(d, 'orders').find({ restaurantId: r._id }).sort({ createdAt: -1 }).toArray();
  const sold = (await C(d, 'offers').find({ restaurantId: r._id, status: 'sold' }).toArray());
  return { orders, stats: { lateCancellations: orders.filter(o => o.lateCancelled).length, mealsRescued: sold.length, foodSaved: sum(sold.map(s => s.originalPrice)),
    chargesRecovered: sum(orders.filter(o => ['retained', 'applied'].includes(o.chargeStatus)).map(o => o.chargeAmount)) } };
});
const NEXT = { Placed: 'Accepted', Accepted: 'Preparing', Preparing: 'Ready' };
on('POST', '/restaurant/orders/:id/next', 'restaurant', async ({ d, u, p }) => {
  const o = await C(d, 'orders').findOne({ _id: p[0], restaurantId: (await myR(d, u))._id }); if (!o || !NEXT[o.status]) throw E(400, 'Cannot move this order forward.');
  await C(d, 'orders').updateOne({ _id: o._id, status: o.status }, { $set: { status: NEXT[o.status] } }); return { ok: true };
});

// ---------- delivery agent ----------
on('GET', '/agent/orders', 'agent', async ({ d, u }) => ({
  available: await C(d, 'orders').find({ status: 'Ready', agentId: null, area: u.area }).toArray(),
  mine: await C(d, 'orders').find({ agentId: u._id, status: 'Out for delivery' }).toArray(),
  delivered: await C(d, 'orders').countDocuments({ agentId: u._id, status: 'Delivered' }) }));
on('POST', '/agent/orders/:id/accept', 'agent', async ({ d, u, p }) => {
  const r = await C(d, 'orders').updateOne({ _id: p[0], status: 'Ready', agentId: null }, { $set: { status: 'Out for delivery', agentId: u._id, agentName: u.name } });
  if (!r.matchedCount) throw E(409, 'Another agent already took this order.'); return { ok: true };
});
on('POST', '/agent/orders/:id/deliver', 'agent', async ({ d, u, p }) => {
  const r = await C(d, 'orders').updateOne({ _id: p[0], agentId: u._id, status: 'Out for delivery' }, { $set: { status: 'Delivered', deliveredAt: new Date() } });
  if (!r.matchedCount) throw E(400, 'Cannot deliver this order.'); return { ok: true };
});

module.exports = async (req, res) => {
  try {
    if (!process.env.MONGODB_URI) throw E(500, 'MONGODB_URI is not set in Vercel environment variables.');
    const d = await getDb(), url = new URL(req.url, 'http://x');
    const path = url.pathname.replace(/^\/api(\/index)?/, '') || '/', body = req.body && typeof req.body === 'object' ? req.body : {};
    for (const [m, re, role, fn] of R) {
      const mt = req.method === m && path.match(re); if (!mt) continue;
      let u = null;
      if (role) {
        const t = verify((req.headers.authorization || '').replace('Bearer ', '')); u = t && await C(d, 'users').findOne({ _id: t.id });
        if (!u) throw E(401, 'Please log in again.'); if (u.role !== role) throw E(403, 'Not allowed for your account type.');
      }
      return res.status(200).json(await fn({ d, u, b: body, p: mt.slice(1), q: Object.fromEntries(url.searchParams) }));
    }
    throw E(404, 'Not found.');
  } catch (e) { res.status(e.status || 500).json({ error: e.status ? e.message : 'Server error: ' + e.message }); }
};
